  
   ------------------------------------
   .ttf          http://ttf.eosnet.com/
   ------------------------------------ 

   The attached font is an original font
   by .ttf, and is freeware.

   Please feel free to distribute this
   font, but keep this readme file with
   it and do not change the font in any
   way.

   ------------------------------------
   How to install the font
   ------------------------------------
  
1  Extract the enclosed font to any
   temporary folder. You can now close
   your unzipping program.

2  Go to the Fonts section of Control
   Panel (Start > Settings > Control
   Panel > Fonts) and choose File >
   Install New Font. In the window that
   comes up, find the font you
   temporarily unzipped. Select it and
   click OK. The font is now installed,
   and can be used with all Windows
   applications.

   ------------------------------------
   .ttf         Copyright (c) 1998-1999
   ------------------------------------
