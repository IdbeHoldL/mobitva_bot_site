<?php

/**
 * sfGuardRememberKey filter form.
 *
 * @package    ##PROJECT_NAME##
 * @subpackage filter
 * @author     ##AUTHOR_NAME##
 * @version    SVN: $Id: sfGuardRememberKeyFormFilter.class.php 12896 2008-11-10 19:02:34Z fabien $
 */
class sfGuardRememberKeyFormFilter extends BasesfGuardRememberKeyFormFilter
{
  public function configure()
  {
  }
}
