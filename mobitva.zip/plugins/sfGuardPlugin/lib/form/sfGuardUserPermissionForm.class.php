<?php

/**
 * sfGuardUserPermission form.
 *
 * @package    form
 * @subpackage sf_guard_user_permission
 * @version    SVN: $Id: sfGuardUserPermissionForm.class.php 7745 2008-03-05 11:05:33Z fabien $
 */
class sfGuardUserPermissionForm extends BasesfGuardUserPermissionForm
{
  public function configure()
  {
  }
}
