<?php

/**
 * sfGuardRememberKey form.
 *
 * @package    form
 * @subpackage sf_guard_remember_key
 * @version    SVN: $Id: sfGuardRememberKeyForm.class.php 7745 2008-03-05 11:05:33Z fabien $
 */
class sfGuardRememberKeyForm extends BasesfGuardRememberKeyForm
{
  public function configure()
  {
  }
}
