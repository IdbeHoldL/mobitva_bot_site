<div class="alert alert-info">
    Пишете сюда все, что хотите.<br />
    Не забывайте соблюдать порядок. Уважайте других участников общения.
    <div class="separator-l"></div>
    <div class="right">IdbeHoldL</div>
    <div class="separator-r"></div>
</div>

<center>
    <div id="mobitba-bot-guest_room"></div>
</center>
<script type="text/javascript">
VK.Widgets.Comments("mobitba-bot-guest_room", {limit: 20, width: "600", attach: "*"});
</script>

