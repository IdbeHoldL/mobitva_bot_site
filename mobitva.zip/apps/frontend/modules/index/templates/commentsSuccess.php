


<div id="vk_comments_page_dev"></div>
<script type="text/javascript">
 VK.Widgets.Comments('vk_comments');
</script>