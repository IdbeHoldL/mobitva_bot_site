<div class="h-container">
    <h2>Ошибка</h2>
</div>
<br />

<div class="alert alert-error" style="padding: 30px;">
    При совершении платежа произошла ошибка.
</div>