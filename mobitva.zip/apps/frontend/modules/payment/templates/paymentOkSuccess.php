<div class="h-container">
    <h2>Платеж успешно завершен</h2>
</div>
<br />

<div class="alert"  style="padding: 30px;">
    Платеж завершен. Лизенция активируется в течении нескольких минут.
</div>