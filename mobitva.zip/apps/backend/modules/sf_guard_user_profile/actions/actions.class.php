<?php

require_once dirname(__FILE__).'/../lib/sf_guard_user_profileGeneratorConfiguration.class.php';
require_once dirname(__FILE__).'/../lib/sf_guard_user_profileGeneratorHelper.class.php';

/**
 * sf_guard_user_profile actions.
 *
 * @package    mobitvabot
 * @subpackage sf_guard_user_profile
 * @author     Your name here
 * @version    SVN: $Id: actions.class.php 12474 2008-10-31 10:41:27Z fabien $
 */
class sf_guard_user_profileActions extends autoSf_guard_user_profileActions
{
}
