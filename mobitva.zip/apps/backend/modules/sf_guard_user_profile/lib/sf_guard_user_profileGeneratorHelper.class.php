<?php

/**
 * sf_guard_user_profile module helper.
 *
 * @package    mobitvabot
 * @subpackage sf_guard_user_profile
 * @author     Your name here
 * @version    SVN: $Id: helper.php 12474 2008-10-31 10:41:27Z fabien $
 */
class sf_guard_user_profileGeneratorHelper extends BaseSf_guard_user_profileGeneratorHelper
{
}
