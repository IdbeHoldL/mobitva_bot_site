<?php

require_once dirname(__FILE__).'/../lib/sf_guard_group_permissionGeneratorConfiguration.class.php';
require_once dirname(__FILE__).'/../lib/sf_guard_group_permissionGeneratorHelper.class.php';

/**
 * sf_guard_group_permission actions.
 *
 * @package    mobitvabot
 * @subpackage sf_guard_group_permission
 * @author     Your name here
 * @version    SVN: $Id: actions.class.php 12474 2008-10-31 10:41:27Z fabien $
 */
class sf_guard_group_permissionActions extends autoSf_guard_group_permissionActions
{
}
