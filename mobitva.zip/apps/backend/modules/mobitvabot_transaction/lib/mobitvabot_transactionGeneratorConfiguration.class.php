<?php

/**
 * mobitvabot_transaction module configuration.
 *
 * @package    mobitvabot
 * @subpackage mobitvabot_transaction
 * @author     Your name here
 * @version    SVN: $Id: configuration.php 12474 2008-10-31 10:41:27Z fabien $
 */
class mobitvabot_transactionGeneratorConfiguration extends BaseMobitvabot_transactionGeneratorConfiguration
{
}
