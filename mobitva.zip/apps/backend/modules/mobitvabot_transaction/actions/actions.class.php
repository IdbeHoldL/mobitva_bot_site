<?php

require_once dirname(__FILE__).'/../lib/mobitvabot_transactionGeneratorConfiguration.class.php';
require_once dirname(__FILE__).'/../lib/mobitvabot_transactionGeneratorHelper.class.php';

/**
 * mobitvabot_transaction actions.
 *
 * @package    mobitvabot
 * @subpackage mobitvabot_transaction
 * @author     Your name here
 * @version    SVN: $Id: actions.class.php 12474 2008-10-31 10:41:27Z fabien $
 */
class mobitvabot_transactionActions extends autoMobitvabot_transactionActions
{
}
