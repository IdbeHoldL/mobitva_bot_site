<?php

/**
 * sf_guard_user module helper.
 *
 * @package    mobitvabot
 * @subpackage sf_guard_user
 * @author     Your name here
 * @version    SVN: $Id: helper.php 12474 2008-10-31 10:41:27Z fabien $
 */
class sf_guard_userGeneratorHelper extends BaseSf_guard_userGeneratorHelper
{
}
