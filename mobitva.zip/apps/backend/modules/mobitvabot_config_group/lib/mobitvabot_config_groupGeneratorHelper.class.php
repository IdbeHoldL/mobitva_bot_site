<?php

/**
 * mobitvabot_config_group module helper.
 *
 * @package    mobitva
 * @subpackage mobitvabot_config_group
 * @author     Your name here
 * @version    SVN: $Id: helper.php 12474 2008-10-31 10:41:27Z fabien $
 */
class mobitvabot_config_groupGeneratorHelper extends BaseMobitvabot_config_groupGeneratorHelper
{
}
