<?php

require_once dirname(__FILE__).'/../lib/mobitvabot_config_groupGeneratorConfiguration.class.php';
require_once dirname(__FILE__).'/../lib/mobitvabot_config_groupGeneratorHelper.class.php';

/**
 * mobitvabot_config_group actions.
 *
 * @package    mobitva
 * @subpackage mobitvabot_config_group
 * @author     Your name here
 * @version    SVN: $Id: actions.class.php 12474 2008-10-31 10:41:27Z fabien $
 */
class mobitvabot_config_groupActions extends autoMobitvabot_config_groupActions
{
}
