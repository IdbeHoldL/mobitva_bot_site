<?php

/**
 * mobitvabot_config module helper.
 *
 * @package    mobitva
 * @subpackage mobitvabot_config
 * @author     Your name here
 * @version    SVN: $Id: helper.php 12474 2008-10-31 10:41:27Z fabien $
 */
class mobitvabot_configGeneratorHelper extends BaseMobitvabot_configGeneratorHelper
{
}
