<?php

/**
 * mobitvabot_config module configuration.
 *
 * @package    mobitva
 * @subpackage mobitvabot_config
 * @author     Your name here
 * @version    SVN: $Id: configuration.php 12474 2008-10-31 10:41:27Z fabien $
 */
class mobitvabot_configGeneratorConfiguration extends BaseMobitvabot_configGeneratorConfiguration
{
}
