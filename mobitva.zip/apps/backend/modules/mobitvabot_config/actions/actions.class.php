<?php

require_once dirname(__FILE__).'/../lib/mobitvabot_configGeneratorConfiguration.class.php';
require_once dirname(__FILE__).'/../lib/mobitvabot_configGeneratorHelper.class.php';

/**
 * mobitvabot_config actions.
 *
 * @package    mobitva
 * @subpackage mobitvabot_config
 * @author     Your name here
 * @version    SVN: $Id: actions.class.php 12474 2008-10-31 10:41:27Z fabien $
 */
class mobitvabot_configActions extends autoMobitvabot_configActions
{
}
