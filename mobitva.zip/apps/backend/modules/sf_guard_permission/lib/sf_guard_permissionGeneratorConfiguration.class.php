<?php

/**
 * sf_guard_permission module configuration.
 *
 * @package    mobitvabot
 * @subpackage sf_guard_permission
 * @author     Your name here
 * @version    SVN: $Id: configuration.php 12474 2008-10-31 10:41:27Z fabien $
 */
class sf_guard_permissionGeneratorConfiguration extends BaseSf_guard_permissionGeneratorConfiguration
{
}
