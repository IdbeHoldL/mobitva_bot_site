<?php

require_once dirname(__FILE__).'/../lib/mobitvabotFilesGeneratorConfiguration.class.php';
require_once dirname(__FILE__).'/../lib/mobitvabotFilesGeneratorHelper.class.php';

/**
 * mobitvabotFiles actions.
 *
 * @package    mobitva
 * @subpackage mobitvabotFiles
 * @author     Your name here
 * @version    SVN: $Id: actions.class.php 12474 2008-10-31 10:41:27Z fabien $
 */
class mobitvabotFilesActions extends autoMobitvabotFilesActions
{
}
