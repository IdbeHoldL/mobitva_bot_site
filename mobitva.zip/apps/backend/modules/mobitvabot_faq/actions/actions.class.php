<?php

require_once dirname(__FILE__).'/../lib/mobitvabot_faqGeneratorConfiguration.class.php';
require_once dirname(__FILE__).'/../lib/mobitvabot_faqGeneratorHelper.class.php';

/**
 * mobitvabot_faq actions.
 *
 * @package    mobitvabot
 * @subpackage mobitvabot_faq
 * @author     Your name here
 * @version    SVN: $Id: actions.class.php 12474 2008-10-31 10:41:27Z fabien $
 */
class mobitvabot_faqActions extends autoMobitvabot_faqActions
{
}
