<?php

/**
 * mobitvabot_news module configuration.
 *
 * @package    mobitvabot
 * @subpackage mobitvabot_news
 * @author     Your name here
 * @version    SVN: $Id: configuration.php 12474 2008-10-31 10:41:27Z fabien $
 */
class mobitvabot_newsGeneratorConfiguration extends BaseMobitvabot_newsGeneratorConfiguration
{
}
