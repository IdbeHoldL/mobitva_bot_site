<?php

/**
 * mobitvabotNews form.
 *
 * @package    mobitvabot
 * @subpackage form
 * @author     Your name here
 */
class mobitvabotNewsForm extends BasemobitvabotNewsForm
{
  public function configure()
  {
  }
}
