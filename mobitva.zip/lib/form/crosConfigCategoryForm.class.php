<?php

/**
 * crosConfigCategory form.
 *
 * @package    mobitva
 * @subpackage form
 * @author     Your name here
 */
class crosConfigCategoryForm extends BasecrosConfigCategoryForm
{
  public function configure()
  {
  }
}
