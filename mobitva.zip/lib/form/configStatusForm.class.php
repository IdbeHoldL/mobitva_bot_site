<?php

/**
 * configStatus form.
 *
 * @package    mobitva
 * @subpackage form
 * @author     Your name here
 */
class configStatusForm extends BaseconfigStatusForm
{
  public function configure()
  {
  }
}
