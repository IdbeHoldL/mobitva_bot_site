<?php

/**
 * botSession form.
 *
 * @package    mobitva
 * @subpackage form
 * @author     Your name here
 */
class botSessionForm extends BasebotSessionForm
{
  public function configure()
  {
  }
}
