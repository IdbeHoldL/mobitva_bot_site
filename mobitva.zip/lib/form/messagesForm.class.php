<?php

/**
 * messages form.
 *
 * @package    mobitva
 * @subpackage form
 * @author     Your name here
 */
class messagesForm extends BasemessagesForm
{
  public function configure()
  {
  }
}
