<?php

/**
 * botconfigRelations form.
 *
 * @package    mobitva
 * @subpackage form
 * @author     Your name here
 */
class botconfigRelationsForm extends BasebotconfigRelationsForm
{
  public function configure()
  {
  }
}
