<?php

/**
 * balanceOperation form.
 *
 * @package    mobitva
 * @subpackage form
 * @author     Your name here
 */
class balanceOperationForm extends BasebalanceOperationForm
{
  public function configure()
  {
  }
}
