<?php

/**
 * mobitvabotConfig form.
 *
 * @package    mobitvabot
 * @subpackage form
 * @author     Your name here
 */
class mobitvabotConfigForm extends BasemobitvabotConfigForm
{
  public function configure()
  {
  }
}
