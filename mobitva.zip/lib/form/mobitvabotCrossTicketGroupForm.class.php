<?php

/**
 * mobitvabotCrossTicketGroup form.
 *
 * @package    mobitvabot
 * @subpackage form
 * @author     Your name here
 */
class mobitvabotCrossTicketGroupForm extends BasemobitvabotCrossTicketGroupForm
{
  public function configure()
  {
  }
}
