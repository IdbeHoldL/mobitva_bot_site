<?php

/**
 * mobitvabotFaq form.
 *
 * @package    mobitvabot
 * @subpackage form
 * @author     Your name here
 */
class mobitvabotFaqForm extends BasemobitvabotFaqForm
{
  public function configure()
  {
  }
}
