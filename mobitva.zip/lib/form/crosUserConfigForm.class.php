<?php

/**
 * crosUserConfig form.
 *
 * @package    mobitva
 * @subpackage form
 * @author     Your name here
 */
class crosUserConfigForm extends BasecrosUserConfigForm
{
  public function configure()
  {
  }
}
