<?php

/**
 * sfGuardUserProfile form.
 *
 * @package    mobitvabot
 * @subpackage form
 * @author     Your name here
 */
class sfGuardUserProfileForm extends BasesfGuardUserProfileForm
{
  public function configure()
  {
  }
}
