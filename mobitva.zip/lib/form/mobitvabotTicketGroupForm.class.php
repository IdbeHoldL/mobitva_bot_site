<?php

/**
 * mobitvabotTicketGroup form.
 *
 * @package    mobitvabot
 * @subpackage form
 * @author     Your name here
 */
class mobitvabotTicketGroupForm extends BasemobitvabotTicketGroupForm
{
  public function configure()
  {
  }
}
