<?php

/**
 * mobitvabotTicket form.
 *
 * @package    mobitvabot
 * @subpackage form
 * @author     Your name here
 */
class mobitvabotTicketForm extends BasemobitvabotTicketForm
{
  public function configure()
  {
  }
}
