<?php

/**
 * mobitvabotTransaction form.
 *
 * @package    mobitvabot
 * @subpackage form
 * @author     Your name here
 */
class mobitvabotTransactionForm extends BasemobitvabotTransactionForm
{
  public function configure()
  {
  }
}
