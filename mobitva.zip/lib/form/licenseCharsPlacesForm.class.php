<?php

/**
 * licenseCharsPlaces form.
 *
 * @package    mobitva
 * @subpackage form
 * @author     Your name here
 */
class licenseCharsPlacesForm extends BaselicenseCharsPlacesForm
{
  public function configure()
  {
  }
}
