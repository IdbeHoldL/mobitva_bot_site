<?php

/**
 * mobitvabotFiles form.
 *
 * @package    mobitvabot
 * @subpackage form
 * @author     Your name here
 */
class mobitvabotFilesForm extends BasemobitvabotFilesForm
{
  public function configure()
  {
  }
}
