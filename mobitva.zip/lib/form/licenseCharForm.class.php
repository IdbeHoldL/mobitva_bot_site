<?php

/**
 * licenseChar form.
 *
 * @package    mobitva
 * @subpackage form
 * @author     Your name here
 */
class licenseCharForm extends BaselicenseCharForm
{
  public function configure()
  {
  }
}
