<?php

/**
 * license form.
 *
 * @package    mobitva
 * @subpackage form
 * @author     Your name here
 */
class licenseForm extends BaselicenseForm
{
  public function configure()
  {
  }
}
