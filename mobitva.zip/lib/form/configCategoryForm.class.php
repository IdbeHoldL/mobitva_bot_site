<?php

/**
 * configCategory form.
 *
 * @package    mobitva
 * @subpackage form
 * @author     Your name here
 */
class configCategoryForm extends BaseconfigCategoryForm
{
  public function configure()
  {
  }
}
