<?php

/**
 * mobitvabotTicket filter form.
 *
 * @package    mobitvabot
 * @subpackage filter
 * @author     Your name here
 */
class mobitvabotTicketFormFilter extends BasemobitvabotTicketFormFilter
{
  public function configure()
  {
  }
}
