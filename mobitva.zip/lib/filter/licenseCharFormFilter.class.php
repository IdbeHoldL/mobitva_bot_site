<?php

/**
 * licenseChar filter form.
 *
 * @package    mobitva
 * @subpackage filter
 * @author     Your name here
 */
class licenseCharFormFilter extends BaselicenseCharFormFilter
{
  public function configure()
  {
  }
}
