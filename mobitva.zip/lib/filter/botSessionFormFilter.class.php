<?php

/**
 * botSession filter form.
 *
 * @package    mobitva
 * @subpackage filter
 * @author     Your name here
 */
class botSessionFormFilter extends BasebotSessionFormFilter
{
  public function configure()
  {
  }
}
