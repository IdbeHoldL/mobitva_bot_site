<?php

/**
 * botconfigRelations filter form.
 *
 * @package    mobitva
 * @subpackage filter
 * @author     Your name here
 */
class botconfigRelationsFormFilter extends BasebotconfigRelationsFormFilter
{
  public function configure()
  {
  }
}
