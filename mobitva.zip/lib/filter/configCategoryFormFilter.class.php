<?php

/**
 * configCategory filter form.
 *
 * @package    mobitva
 * @subpackage filter
 * @author     Your name here
 */
class configCategoryFormFilter extends BaseconfigCategoryFormFilter
{
  public function configure()
  {
  }
}
