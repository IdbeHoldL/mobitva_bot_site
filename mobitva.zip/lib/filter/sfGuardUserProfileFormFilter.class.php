<?php

/**
 * sfGuardUserProfile filter form.
 *
 * @package    mobitvabot
 * @subpackage filter
 * @author     Your name here
 */
class sfGuardUserProfileFormFilter extends BasesfGuardUserProfileFormFilter
{
  public function configure()
  {
  }
}
