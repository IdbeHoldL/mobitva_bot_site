<?php

/**
 * Project filter form base class.
 *
 * @package    mobitvabot
 * @subpackage filter
 * @author     Your name here
 */
abstract class BaseFormFilterPropel extends sfFormFilterPropel
{
  public function setup()
  {
  }
}
