<?php

/**
 * license filter form.
 *
 * @package    mobitva
 * @subpackage filter
 * @author     Your name here
 */
class licenseFormFilter extends BaselicenseFormFilter
{
  public function configure()
  {
  }
}
