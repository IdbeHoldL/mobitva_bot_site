<?php

/**
 * mobitvabotConfigGroup filter form.
 *
 * @package    mobitvabot
 * @subpackage filter
 * @author     Your name here
 */
class mobitvabotConfigGroupFormFilter extends BasemobitvabotConfigGroupFormFilter
{
  public function configure()
  {
  }
}
