<?php

/**
 * mobitvabotTransaction filter form.
 *
 * @package    mobitvabot
 * @subpackage filter
 * @author     Your name here
 */
class mobitvabotTransactionFormFilter extends BasemobitvabotTransactionFormFilter
{
  public function configure()
  {
  }
}
