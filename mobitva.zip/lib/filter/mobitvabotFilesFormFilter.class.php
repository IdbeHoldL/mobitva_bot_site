<?php

/**
 * mobitvabotFiles filter form.
 *
 * @package    mobitvabot
 * @subpackage filter
 * @author     Your name here
 */
class mobitvabotFilesFormFilter extends BasemobitvabotFilesFormFilter
{
  public function configure()
  {
  }
}
