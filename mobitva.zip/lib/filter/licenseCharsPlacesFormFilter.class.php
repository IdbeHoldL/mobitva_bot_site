<?php

/**
 * licenseCharsPlaces filter form.
 *
 * @package    mobitva
 * @subpackage filter
 * @author     Your name here
 */
class licenseCharsPlacesFormFilter extends BaselicenseCharsPlacesFormFilter
{
  public function configure()
  {
  }
}
