<?php

/**
 * crosConfigCategory filter form.
 *
 * @package    mobitva
 * @subpackage filter
 * @author     Your name here
 */
class crosConfigCategoryFormFilter extends BasecrosConfigCategoryFormFilter
{
  public function configure()
  {
  }
}
