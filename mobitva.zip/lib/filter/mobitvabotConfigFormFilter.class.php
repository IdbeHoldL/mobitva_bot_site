<?php

/**
 * mobitvabotConfig filter form.
 *
 * @package    mobitvabot
 * @subpackage filter
 * @author     Your name here
 */
class mobitvabotConfigFormFilter extends BasemobitvabotConfigFormFilter
{
  public function configure()
  {
  }
}
