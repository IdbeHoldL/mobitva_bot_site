<?php

/**
 * mobitvabotNews filter form.
 *
 * @package    mobitvabot
 * @subpackage filter
 * @author     Your name here
 */
class mobitvabotNewsFormFilter extends BasemobitvabotNewsFormFilter
{
  public function configure()
  {
  }
}
