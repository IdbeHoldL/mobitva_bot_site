<?php

/**
 * mobitvabotTicketGroup filter form.
 *
 * @package    mobitvabot
 * @subpackage filter
 * @author     Your name here
 */
class mobitvabotTicketGroupFormFilter extends BasemobitvabotTicketGroupFormFilter
{
  public function configure()
  {
  }
}
