<?php

/**
 * balanceOperation filter form.
 *
 * @package    mobitva
 * @subpackage filter
 * @author     Your name here
 */
class balanceOperationFormFilter extends BasebalanceOperationFormFilter
{
  public function configure()
  {
  }
}
