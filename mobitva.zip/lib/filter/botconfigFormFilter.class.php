<?php

/**
 * botconfig filter form.
 *
 * @package    mobitva
 * @subpackage filter
 * @author     Your name here
 */
class botconfigFormFilter extends BasebotconfigFormFilter
{
  public function configure()
  {
  }
}
