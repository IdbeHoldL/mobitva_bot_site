<?php

/**
 * messages filter form.
 *
 * @package    mobitva
 * @subpackage filter
 * @author     Your name here
 */
class messagesFormFilter extends BasemessagesFormFilter
{
  public function configure()
  {
  }
}
