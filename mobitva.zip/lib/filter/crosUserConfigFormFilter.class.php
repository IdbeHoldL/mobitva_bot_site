<?php

/**
 * crosUserConfig filter form.
 *
 * @package    mobitva
 * @subpackage filter
 * @author     Your name here
 */
class crosUserConfigFormFilter extends BasecrosUserConfigFormFilter
{
  public function configure()
  {
  }
}
