<?php

/**
 * configStatus filter form.
 *
 * @package    mobitva
 * @subpackage filter
 * @author     Your name here
 */
class configStatusFormFilter extends BaseconfigStatusFormFilter
{
  public function configure()
  {
  }
}
