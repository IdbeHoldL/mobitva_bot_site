<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of imageHepler
 *
 * @author q
 */
class imageHepler {
  
  // массив с картинками
  public $images = array();
  public $countRows = 5;
  public $images = array();
  
  public addImage($url){
    
    
//    $this->$images[] = 
  }
  
}

?>
